from greyscale import greyscale
from negativo import negativo